import { useState, useEffect } from "react";
import "../styles/global.css";
import SplashScreen   from "./SplashScreen";
import LoginScreen    from "./LoginScreen";
import BundleScreen   from "./BundleScreen";
import ChatScreen     from "./ChatScreen";
import AdminDashboard from "./AdminDashboard";

/**
 * Screen flow:
 *   splash → login → bundle → chat
 *                           ↘ admin (owner dashboard, reachable from login or chat header)
 */
export default function LetsTalk() {
  const [screen, setScreen] = useState("splash"); // splash | login | bundle | chat | admin
  const [user,   setUser]   = useState(null);
  const [bundle, setBundle] = useState(null);
  const [prevScreen, setPrev] = useState("login"); // where admin was opened from

  // Auto-advance splash
  useEffect(() => {
    if (screen === "splash") {
      const t = setTimeout(() => setScreen("login"), 2400);
      return () => clearTimeout(t);
    }
  }, [screen]);

  const goAdmin = (from) => {
    setPrev(from || screen);
    setScreen("admin");
  };

  if (screen === "splash")  return <SplashScreen />;
  if (screen === "login")   return <LoginScreen  onLogin={u => { setUser(u); setScreen("bundle"); }} onAdmin={() => goAdmin("login")} />;
  if (screen === "bundle")  return <BundleScreen user={user} onSelect={b => { setBundle(b); setScreen("chat"); }} />;
  if (screen === "chat")    return <ChatScreen   user={user} bundle={bundle} onAdmin={() => goAdmin("chat")} onUpgrade={() => setScreen("bundle")} />;
  if (screen === "admin")   return <AdminDashboard onBack={() => setScreen(prevScreen)} />;

  return null;
}
